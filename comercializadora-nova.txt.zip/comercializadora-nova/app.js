
"use strict";

/* =========================================
   COMERCIALIZADORA NOVA
   ETAPA 1: FUNCIONES DE LA TIENDA
   ========================================= */


/* 1. DATOS DE LOS PRODUCTOS */

const productos = [
    {
        id: 1,
        nombre: "Audífonos inalámbricos",
        categoria: "Tecnología",
        precio: 89900,
        imagen: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=500&q=80",
        descripcion: "Audífonos para escuchar tu música."
    },
    {
        id: 2,
        nombre: "Reloj inteligente",
        categoria: "Tecnología",
        precio: 129900,
        imagen: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=500&q=80",
        descripcion: "Reloj moderno para el día a día."
    },
    {
        id: 3,
        nombre: "Lámpara de escritorio",
        categoria: "Hogar",
        precio: 64900,
        imagen: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=500&q=80",
        descripcion: "Ilumina tu espacio de trabajo."
    },
    {
        id: 4,
        nombre: "Mochila urbana",
        categoria: "Accesorios",
        precio: 79900,
        imagen: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=500&q=80",
        descripcion: "Una mochila para tus actividades."
    },
    {
        id: 5,
        nombre: "Parlante portátil",
        categoria: "Tecnología",
        precio: 109900,
        imagen: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=500&q=80",
        descripcion: "Disfruta tu música donde quieras."
    },
    {
        id: 6,
        nombre: "Taza de cerámica",
        categoria: "Hogar",
        precio: 24900,
        imagen: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=500&q=80",
        descripcion: "Una taza para tus bebidas favoritas."
    },
    {
        id: 7,
        nombre: "Gafas de sol",
        categoria: "Accesorios",
        precio: 49900,
        imagen: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=500&q=80",
        descripcion: "Un accesorio para completar tu estilo."
    },
    {
        id: 8,
        nombre: "Teclado inalámbrico",
        categoria: "Tecnología",
        precio: 94900,
        imagen: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=500&q=80",
        descripcion: "Un teclado para tu escritorio."
    }
];


/* 2. REFERENCIAS A LOS ELEMENTOS HTML */

const listaProductos = document.getElementById("lista-productos");
const buscador = document.getElementById("buscador");
const limpiarBusqueda = document.getElementById("limpiar-busqueda");
const botonesCategorias = document.querySelectorAll(".categoria");
const totalProductos = document.getElementById("total-productos");
const mensajeVacio = document.getElementById("mensaje-vacio");

const botonCarrito = document.getElementById("boton-carrito");
const contadorCarrito = document.getElementById("contador-carrito");
const listaCarrito = document.getElementById("lista-carrito");
const totalCarrito = document.getElementById("total-carrito");
const botonVaciarCarrito = document.getElementById("vaciar-carrito");

const notificacion = document.getElementById("notificacion");
const anio = document.getElementById("anio");


/* 3. ESTADO INICIAL */

let categoriaSeleccionada = "Todos";
let textoBusqueda = "";
const carrito = new Map();


/* 4. FORMATO DE PRECIOS COLOMBIANOS */

const formatoCOP = new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0
});

function formatearPrecio(precio) {
    return formatoCOP.format(precio);
}


/* 5. MOSTRAR PRODUCTOS EN PANTALLA */

function mostrarProductos() {
    const productosFiltrados = productos.filter((producto) => {
        const coincideCategoria =
            categoriaSeleccionada === "Todos" ||
            producto.categoria === categoriaSeleccionada;

        const nombre = producto.nombre.toLowerCase();
        const categoria = producto.categoria.toLowerCase();
        const busqueda = textoBusqueda.toLowerCase();

        const coincideBusqueda =
            nombre.includes(busqueda) ||
            categoria.includes(busqueda);

        return coincideCategoria && coincideBusqueda;
    });

    listaProductos.replaceChildren();

    productosFiltrados.forEach((producto) => {
        const tarjeta = document.createElement("article");
        tarjeta.className = "producto";

        const imagenContenedor = document.createElement("div");
        imagenContenedor.className = "producto-imagen";

        const imagen = document.createElement("img");
        imagen.src = producto.imagen;
        imagen.alt = producto.nombre;
        imagen.loading = "lazy";

        imagen.addEventListener("error", () => {
            imagen.alt = producto.nombre + " (imagen no disponible)";
            imagen.removeAttribute("src");
        }, { once: true });

        imagenContenedor.appendChild(imagen);

        const informacion = document.createElement("div");
        informacion.className = "producto-info";

        const categoria = document.createElement("span");
        categoria.className = "producto-categoria";
        categoria.textContent = producto.categoria;

        const nombre = document.createElement("h3");
        nombre.textContent = producto.nombre;

        const descripcion = document.createElement("p");
        descripcion.className = "texto-secundario";
        descripcion.textContent = producto.descripcion;

        const precio = document.createElement("strong");
        precio.className = "producto-precio";
        precio.textContent = formatearPrecio(producto.precio);

        const boton = document.createElement("button");
        boton.type = "button";
        boton.className = "boton-agregar";
        boton.dataset.id = producto.id;
        boton.textContent = "Agregar al carrito";
        boton.setAttribute(
            "aria-label",
            "Agregar " + producto.nombre + " al carrito"
        );

        informacion.append(
            categoria,
            nombre,
            descripcion,
            precio,
            boton
        );

        tarjeta.append(imagenContenedor, informacion);
        listaProductos.appendChild(tarjeta);
    });

    totalProductos.textContent =
        productosFiltrados.length +
        (productosFiltrados.length === 1 ? " producto" : " productos");

    mensajeVacio.hidden = productosFiltrados.length !== 0;
}


/* 6. BUSCADOR DE PRODUCTOS */

buscador.addEventListener("input", () => {
    textoBusqueda = buscador.value.trim();
    mostrarProductos();
});

limpiarBusqueda.addEventListener("click", () => {
    buscador.value = "";
    textoBusqueda = "";
    mostrarProductos();
    buscador.focus();
});


/* 7. FILTRAR POR CATEGORÍA */

botonesCategorias.forEach((boton) => {
    boton.addEventListener("click", () => {
        categoriaSeleccionada = boton.dataset.categoria;

        botonesCategorias.forEach((otroBoton) => {
            otroBoton.classList.toggle(
                "activa",
                otroBoton === boton
            );
        });

        mostrarProductos();
    });
});


/* 8. NOTIFICACIONES */

function mostrarNotificacion(mensaje) {
    notificacion.textContent = mensaje;
    notificacion.classList.add("visible");

    window.clearTimeout(mostrarNotificacion.temporizador);

    mostrarNotificacion.temporizador = window.setTimeout(() => {
        notificacion.classList.remove("visible");
    }, 2500);
}


/* 9. AGREGAR PRODUCTOS AL CARRITO */

listaProductos.addEventListener("click", (evento) => {
    const boton = evento.target.closest(".boton-agregar");

    if (!boton) {
        return;
    }

    const id = Number(boton.dataset.id);
    const producto = productos.find((item) => item.id === id);

    if (!producto) {
        mostrarNotificacion("No encontramos ese producto.");
        return;
    }

    const articuloExistente = carrito.get(id);

    if (articuloExistente) {
        articuloExistente.cantidad += 1;
    } else {
        carrito.set(id, {
            producto: producto,
            cantidad: 1
        });
    }

    mostrarCarrito();
    mostrarNotificacion(producto.nombre + " agregado al carrito.");
});


/* 10. DIBUJAR EL CARRITO Y CALCULAR EL TOTAL */

function mostrarCarrito() {
    listaCarrito.replaceChildren();

    let cantidadTotal = 0;
    let importeTotal = 0;

    carrito.forEach((articulo, id) => {
        const producto = articulo.producto;
        const cantidad = articulo.cantidad;

        cantidadTotal += cantidad;
        importeTotal += producto.precio * cantidad;

        const fila = document.createElement("div");
        fila.className = "item-carrito";

        const informacion = document.createElement("div");

        const nombre = document.createElement("strong");
        nombre.textContent = producto.nombre;

        const detalle = document.createElement("small");
        detalle.textContent =
            formatearPrecio(producto.precio) + " por unidad";

        informacion.append(nombre, detalle);

        const controles = document.createElement("div");
        controles.className = "cantidad-carrito";

        const botonMenos = document.createElement("button");
        botonMenos.type = "button";
        botonMenos.textContent = "−";
        botonMenos.setAttribute(
            "aria-label",
            "Reducir cantidad de " + producto.nombre
        );
        botonMenos.dataset.accion = "menos";
        botonMenos.dataset.id = id;

        const cantidadTexto = document.createElement("span");
        cantidadTexto.textContent = cantidad;

        const botonMas = document.createElement("button");
        botonMas.type = "button";
        botonMas.textContent = "+";
        botonMas.setAttribute(
            "aria-label",
            "Aumentar cantidad de " + producto.nombre
        );
        botonMas.dataset.accion = "mas";
        botonMas.dataset.id = id;

        const botonEliminar = document.createElement("button");
        botonEliminar.type = "button";
        botonEliminar.className = "boton-eliminar";
        botonEliminar.textContent = "Eliminar";
        botonEliminar.dataset.accion = "eliminar";
        botonEliminar.dataset.id = id;

        controles.append(
            botonMenos,
            cantidadTexto,
            botonMas,
            botonEliminar
        );

        fila.append(informacion, controles);
        listaCarrito.appendChild(fila);
    });

    if (carrito.size === 0) {
        const mensaje = document.createElement("p");
        mensaje.className = "texto-secundario";
        mensaje.textContent =
            "Tu carrito está vacío. Agrega un producto para comenzar.";

        listaCarrito.appendChild(mensaje);
    }

    contadorCarrito.textContent = cantidadTotal;
    totalCarrito.textContent = formatearPrecio(importeTotal);
}


/* 11. MODIFICAR O ELIMINAR ARTÍCULOS */

listaCarrito.addEventListener("click", (evento) => {
    const boton = evento.target.closest("button[data-accion]");

    if (!boton) {
        return;
    }

    const id = Number(boton.dataset.id);
    const accion = boton.dataset.accion;
    const articulo = carrito.get(id);

    if (!articulo) {
        return;
    }

    if (accion === "mas") {
        articulo.cantidad += 1;
    }

    if (accion === "menos") {
        articulo.cantidad -= 1;

        if (articulo.cantidad <= 0) {
            carrito.delete(id);
        }
    }

    if (accion === "eliminar") {
        carrito.delete(id);
    }

    mostrarCarrito();
});


/* 12. BOTONES DEL CARRITO */

botonVaciarCarrito.addEventListener("click", () => {
    if (carrito.size === 0) {
        mostrarNotificacion("El carrito ya está vacío.");
        return;
    }

    carrito.clear();
    mostrarCarrito();
    mostrarNotificacion("Has vaciado el carrito.");
});

botonCarrito.addEventListener("click", () => {
    document.getElementById("carrito").scrollIntoView({
        behavior: "smooth"
    });
});


/* 13. AÑO AUTOMÁTICO DEL PIE DE PÁGINA */

anio.textContent = new Date().getFullYear();


/* 14. INICIAR LA TIENDA */

mostrarProductos();
mostrarCarrito();

console.log("Comercializadora Nova se ha iniciado correctamente.");
console.log("Productos disponibles:", productos.length);
